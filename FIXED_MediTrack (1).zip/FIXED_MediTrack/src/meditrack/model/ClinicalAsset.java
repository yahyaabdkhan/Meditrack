package meditrack.model;

import java.io.Serializable;

/**
 * Represents a physical medical asset/equipment within the hospital.
 * Tracks availability to prevent double-booking as per business logic.
 */
public class ClinicalAsset implements Serializable {
    private static final long serialVersionUID = 1L;

    private String assetID;
    private String name;
    private EquipmentType type;
    private boolean isAvailable;

    public ClinicalAsset(String assetID, String name, EquipmentType type) {
        this.assetID = assetID;
        this.name = name;
        this.type = type;
        this.isAvailable = true; // Default to available
    }

    public String getAssetID() {
        return assetID;
    }

    public String getName() {
        return name;
    }

    public EquipmentType getType() {
        return type;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    @Override
    public String toString() {
        return "Asset [" + assetID + "]: " + name + " (" + type + ") - " + (isAvailable ? "Available" : "In Use");
    }
}
