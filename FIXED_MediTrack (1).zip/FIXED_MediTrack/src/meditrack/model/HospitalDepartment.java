package meditrack.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a hospital department containing resources (staff and assets).
 * Demonstrates Aggregation principle as resources exist independently.
 */
public class HospitalDepartment implements Serializable {
    private static final long serialVersionUID = 1L;

    private String departmentName;
    private List<HealthcarePractitioner> staff;
    private List<ClinicalAsset> assets;

    public HospitalDepartment(String name) {
        this.departmentName = name;
        this.staff = new ArrayList<>();
        this.assets = new ArrayList<>();
    }

    public void addStaff(HealthcarePractitioner p) {
        staff.add(p);
    }

    public void addAsset(ClinicalAsset a) {
        assets.add(a);
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public List<HealthcarePractitioner> getStaff() {
        return staff;
    }

    public List<ClinicalAsset> getAssets() {
        return assets;
    }

    @Override
    public String toString() {
        return "Department: " + departmentName + " [Staff: " + staff.size() + ", Assets: " + assets.size() + "]";
    }
}
