package meditrack.model;

import java.io.Serializable;
import java.util.Date;

/**
 * Represents a patient's medical record.
 * Stores essential demographic data and identity reference.
 */
public class PatientRecord implements Serializable {
    private static final long serialVersionUID = 1L;

    private String medicalReferenceID;
    private String name;
    private Date dateOfBirth;

    public PatientRecord(String medicalReferenceID, String name, Date dateOfBirth) {
        this.medicalReferenceID = medicalReferenceID;
        this.name = name;
        this.dateOfBirth = dateOfBirth;
    }

    public String getMedicalReferenceID() {
        return medicalReferenceID;
    }

    public String getName() {
        return name;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    @Override
    public String toString() {
        return "Patient [" + medicalReferenceID + "]: " + name;
    }
}
