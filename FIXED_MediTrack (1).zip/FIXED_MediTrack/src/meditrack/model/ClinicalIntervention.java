package meditrack.model;

import java.io.Serializable;
import java.util.Date;

/**
 * Represents a medical procedure or intervention.
 * This is the central 'nexus' object linking practitioners, assets, and patients.
 */
public class ClinicalIntervention implements Serializable {
    private static final long serialVersionUID = 1L;

    private String interventionID;
    private PatientRecord patient;
    private HealthcarePractitioner practitioner;
    private ClinicalAsset asset;
    private Date scheduledTime;
    private ProcedureStatus status;
    private int durationMinutes;

    public ClinicalIntervention(String interventionID, PatientRecord patient, 
                               HealthcarePractitioner practitioner, ClinicalAsset asset, 
                               Date scheduledTime, int durationMinutes) {
        this.interventionID = interventionID;
        this.patient = patient;
        this.practitioner = practitioner;
        this.asset = asset;
        this.scheduledTime = scheduledTime;
        this.durationMinutes = durationMinutes;
        this.status = ProcedureStatus.SCHEDULED;
    }

    public String getInterventionID() {
        return interventionID;
    }

    public PatientRecord getPatient() {
        return patient;
    }

    public HealthcarePractitioner getPractitioner() {
        return practitioner;
    }

    public ClinicalAsset getAsset() {
        return asset;
    }

    public Date getScheduledTime() {
        return scheduledTime;
    }

    public ProcedureStatus getStatus() {
        return status;
    }

    public void setStatus(ProcedureStatus status) {
        this.status = status;
    }

    public int getDurationMinutes() {
        return durationMinutes;
    }

    @Override
    public String toString() {
        return "Intervention [" + interventionID + "] - Status: " + status + 
               "\n  Patient: " + patient.getName() + 
               "\n  Practitioner: " + practitioner.getFullName() + 
               "\n  Asset: " + asset.getName();
    }
}
