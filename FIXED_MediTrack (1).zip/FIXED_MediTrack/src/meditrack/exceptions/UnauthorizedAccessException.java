package meditrack.exceptions;

/**
 * Custom exception thrown when a user without appropriate privileges
 * attempts to access a restricted menu or reassign core resources.
 */
public class UnauthorizedAccessException extends RuntimeException {
    public UnauthorizedAccessException(String message) {
        super(message);
    }
}
