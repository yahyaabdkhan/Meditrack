package meditrack.model;

/**
 * Defines the classification of medical assets managed by the hospital.
 */
public enum EquipmentType {
    IMAGING,
    SURGICAL,
    DIAGNOSTIC,
    LIFE_SUPPORT
}
