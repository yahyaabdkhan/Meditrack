package meditrack.model;

/**
 * Represents a medical professional (Nurse, Physician) assigned to a department.
 * Demonstrates inheritance from SystemUser.
 */
public class HealthcarePractitioner extends SystemUser {
    private static final long serialVersionUID = 1L;
    
    private String licenseId;

    public HealthcarePractitioner(String loginId, String password, String fullName, String licenseId) {
        super(loginId, password, fullName);
        this.licenseId = licenseId;
    }

    public String getLicenseId() {
        return licenseId;
    }

    @Override
    public String toString() {
        return "Practitioner: " + fullName + " [ID: " + licenseId + "]";
    }
}
