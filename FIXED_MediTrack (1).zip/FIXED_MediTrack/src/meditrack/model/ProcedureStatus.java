package meditrack.model;

/**
 * Represents the strict lifecycle states of a Clinical Intervention.
 * Utilizing enums prevents invalid string states as required by NQF Level 5 standards.
 */
public enum ProcedureStatus {
    SCHEDULED,
    IN_PROGRESS,
    COMPLETED,
    ABORTED
}
