package meditrack.model;

import java.io.Serializable;

/**
 * Abstract base class representing any user capable of authenticating
 * with the MediTrack console system.
 * Implements Serializable to allow complete system state saving.
 */
public abstract class SystemUser implements Serializable {
    private static final long serialVersionUID = 1L;
    
    protected String loginId;
    protected String passwordHash; // Simplified for prototype
    protected String fullName;

    public SystemUser(String loginId, String passwordHash, String fullName) {
        this.loginId = loginId;
        this.passwordHash = passwordHash;
        this.fullName = fullName;
    }

    /**
     * Authenticates the user.
     * @param inputId The provided username.
     * @param inputPass The provided password.
     * @return true if credentials match, false otherwise.
     */
    public boolean authenticate(String inputId, String inputPass) {
        return this.loginId.equals(inputId) && this.passwordHash.equals(inputPass);
    }

    public String getLoginId() {
        return loginId;
    }

    public String getFullName() {
        return fullName;
    }
}
