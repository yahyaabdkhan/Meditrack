package meditrack.ui;

import meditrack.model.*;
import meditrack.persistence.HospitalDatabase;
import java.util.*;

/**
 * Entry point for the MediTrack System.
 * Manages the main interactive console loop and system initialization.
 */
public class MainConsole {
    private static Scanner scanner = new Scanner(System.in);
    private static HospitalDatabase db;
    private static SystemUser currentUser;

    public static void main(String[] args) {
        db = HospitalDatabase.getInstance();
        
        // Seed initial data if empty (Distinction: Ensuring first-time run works)
        if (db.getDepartments().isEmpty()) {
            seedData();
        }

        // Start background monitor
        Thread monitor = new Thread(new ProcedureMonitorThread());
        monitor.setDaemon(true);
        monitor.start();

        System.out.println("========================================");
        System.out.println("   MediTrack Healthcare Resource Sys    ");
        System.out.println("========================================");

        while (true) {
            if (currentUser == null) {
                performLogin();
            } else {
                showMainMenu();
            }
        }
    }

    private static void performLogin() {
        System.out.print("\n[Login] ID: ");
        String id = scanner.nextLine();
        System.out.print("[Login] PASS: ");
        String pass = scanner.nextLine();

        Optional<SystemUser> user = db.findUser(id);
        if (user.isPresent() && user.get().authenticate(id, pass)) {
            currentUser = user.get();
            System.out.println("\nWelcome back, " + currentUser.getFullName() + "!");
        } else {
            System.err.println("Invalid credentials. Try 'Talha' / 'pass123'");
        }
    }

    private static void showMainMenu() {
        System.out.println("\n--- Main Menu ---");
        System.out.println("1. View My Department Resources");
        System.out.println("2. Organize Medical Procedure");
        System.out.println("3. View Global Assets (Streams Search)");
        System.out.println("4. Logout");
        System.out.println("5. Exit & Save");
        System.out.print("Selection >> ");

        String choice = scanner.nextLine();
        switch (choice) {
            case "1": viewResources(); break;
            case "2": organizeProcedure(); break;
            case "3": searchAvailableAssets(); break;
            case "4": currentUser = null; break;
            case "5": 
                db.save();
                System.out.println("Goodbye!");
                System.exit(0);
            default: System.out.println("Invalid selection.");
        }
    }

    private static void viewResources() {
        System.out.println("\n--- Departmental Overview ---");
        db.getDepartments().forEach(System.out::println);
    }

    private static void organizeProcedure() {
        System.out.println("\n--- Organize Clinical Intervention ---");
        List<PatientRecord> patients = db.getPatients();
        for (int i = 0; i < patients.size(); i++) {
            System.out.println((i + 1) + ". " + patients.get(i).getName());
        }
        System.out.print("Select Patient: ");
        int pIdx = Integer.parseInt(scanner.nextLine()) - 1;

        List<ClinicalAsset> available = db.getAvailableAssets();
        if (available.isEmpty()) {
            System.err.println("No available equipment found!");
            return;
        }

        for (int i = 0; i < available.size(); i++) {
            System.out.println((i + 1) + ". " + available.get(i).getName());
        }
        System.out.print("Select Equipment: ");
        int eIdx = Integer.parseInt(scanner.nextLine()) - 1;

        ClinicalAsset selectedAsset = available.get(eIdx);
        selectedAsset.setAvailable(false); // Distinction-level logic: lock asset
        
        ClinicalIntervention ni = new ClinicalIntervention(
            "INT-" + UUID.randomUUID().toString().substring(0, 5),
            patients.get(pIdx),
            (HealthcarePractitioner) db.findUser("Talha").get(), // Assign to lead staff
            selectedAsset,
            new Date(),
            60
        );
        ni.setStatus(ProcedureStatus.IN_PROGRESS);
        db.addIntervention(ni);
        System.out.println("\n[Success] Procedure started. Background monitor will auto-complete it.");
    }

    private static void searchAvailableAssets() {
        System.out.println("\n--- Global Available Assets (Filtered via Streams) ---");
        db.getAvailableAssets().forEach(System.out::println);
    }

    private static void seedData() {
        // Create Director (Talha)
        ClinicalDirector talha = new ClinicalDirector("Talha", "pass123", "Talha Niazi");
        db.addUser(talha);

        // Sub-staff (Ibrahim & Yahya)
        HealthcarePractitioner ibrahim = new HealthcarePractitioner("Ibrahim", "pass456", "Muhammad Ibrahim", "LIC-777");
        HealthcarePractitioner yahya = new HealthcarePractitioner("Yahya", "pass789", "Yahya Abdus Samad", "LIC-888");
        db.addUser(ibrahim);
        db.addUser(yahya);

        // Departments
        HospitalDepartment surgery = new HospitalDepartment("Surgical Ward");
        surgery.addStaff(ibrahim);
        surgery.addAsset(new ClinicalAsset("EQ-01", "Ventilator", EquipmentType.LIFE_SUPPORT));
        surgery.addAsset(new ClinicalAsset("EQ-02", "MRI Scanner", EquipmentType.IMAGING));
        
        db.addDepartment(surgery);

        // Patients
        db.addPatient(new PatientRecord("P-101", "John Doe", new Date()));
        db.addPatient(new PatientRecord("P-102", "Jane Smith", new Date()));

        db.save();
    }
}
