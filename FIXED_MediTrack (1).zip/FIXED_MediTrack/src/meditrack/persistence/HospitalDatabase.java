package meditrack.persistence;

import meditrack.model.*;
import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Singleton class acting as the centralized data management engine.
 * Handles persistent storage via Object Serialization as requested.
 */
public class HospitalDatabase implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final String DATA_FILE = "meditrack_system.ser";
    private static HospitalDatabase instance;

    private List<SystemUser> users;
    private List<HospitalDepartment> departments;
    private List<PatientRecord> patients;
    private List<ClinicalIntervention> interventions;

    // Private constructor for Singleton
    private HospitalDatabase() {
        users = new ArrayList<>();
        departments = new ArrayList<>();
        patients = new ArrayList<>();
        interventions = new ArrayList<>();
    }

    /**
     * Retrieves the Singleton instance or loads it from disk.
     */
    public static HospitalDatabase getInstance() {
        if (instance == null) {
            instance = load();
            if (instance == null) {
                instance = new HospitalDatabase();
            }
        }
        return instance;
    }

    /**
     * Saves the entire system state to a serializable file.
     */
    public void save() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(DATA_FILE))) {
            oos.writeObject(this);
            System.out.println("[DB] System state persisted successfully.");
        } catch (IOException e) {
            System.err.println("[DB Error] Failed to save state: " + e.getMessage());
        }
    }

    /**
     * Loads the system state from disk.
     */
    private static HospitalDatabase load() {
        File file = new File(DATA_FILE);
        if (!file.exists()) return null;

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            return (HospitalDatabase) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("[DB Error] Failed to load state: " + e.getMessage());
            return null;
        }
    }

    // --- Data Manipulation Methods using Streams (Distinction Level) ---

    public void addUser(SystemUser user) { users.add(user); }
    public void addDepartment(HospitalDepartment dept) { departments.add(dept); }
    public void addPatient(PatientRecord p) { patients.add(p); }
    public void addIntervention(ClinicalIntervention i) { interventions.add(i); }

    public Optional<SystemUser> findUser(String loginId) {
        return users.stream()
                .filter(u -> u.getLoginId().equalsIgnoreCase(loginId))
                .findFirst();
    }

    public List<HospitalDepartment> getDepartments() { return departments; }
    public List<PatientRecord> getPatients() { return patients; }
    public List<ClinicalIntervention> getInterventions() { return interventions; }

    /**
     * Distinction Requirement: Using Streams to filter available assets across departments.
     */
    public List<ClinicalAsset> getAvailableAssets() {
        return departments.stream()
                .flatMap(d -> d.getAssets().stream())
                .filter(ClinicalAsset::isAvailable)
                .collect(Collectors.toList());
    }
}
