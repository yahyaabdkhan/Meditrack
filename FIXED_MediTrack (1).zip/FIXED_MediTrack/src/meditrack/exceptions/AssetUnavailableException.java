package meditrack.exceptions;

/**
 * Custom exception thrown when attempting to reassign or book
 * a clinical asset that is currently logged as "IN USE".
 */
public class AssetUnavailableException extends Exception {
    public AssetUnavailableException(String message) {
        super(message);
    }
}
