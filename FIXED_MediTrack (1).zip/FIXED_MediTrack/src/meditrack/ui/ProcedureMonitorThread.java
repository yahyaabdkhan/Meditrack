package meditrack.ui;

import meditrack.model.ClinicalIntervention;
import meditrack.model.ProcedureStatus;
import meditrack.persistence.HospitalDatabase;

/**
 * Distinction Requirement: Multi-threaded monitor.
 * Runs in the background to simulate real-time state transitions of procedures.
 */
public class ProcedureMonitorThread implements Runnable {
    private boolean running = true;

    @Override
    public void run() {
        System.out.println("[System Monitor] Background thread started.");
        
        while (running) {
            try {
                // Monitor intervals
                Thread.sleep(10000); // Check every 10 seconds
                
                HospitalDatabase db = HospitalDatabase.getInstance();
                
                // Transition logic
                db.getInterventions().forEach(interv -> {
                    if (interv.getStatus() == ProcedureStatus.IN_PROGRESS) {
                        // For prototype simulation, we auto-complete after some time
                        interv.setStatus(ProcedureStatus.COMPLETED);
                        interv.getAsset().setAvailable(true);
                        System.out.println("\n[Auto-Update] Intervention " + interv.getInterventionID() + " marked as COMPLETED.");
                    }
                });
                
            } catch (InterruptedException e) {
                System.out.println("[System Monitor] Interrupted.");
                break;
            }
        }
    }

    public void stop() {
        running = false;
    }
}
