package meditrack.model;

/**
 * Represents a high-level administrative user with privileges to oversee
 * department-wide resource reallocation.
 */
public class ClinicalDirector extends SystemUser {
    private static final long serialVersionUID = 1L;

    public ClinicalDirector(String loginId, String password, String fullName) {
        super(loginId, password, fullName);
    }

    @Override
    public String toString() {
        return "Clinical Director: " + fullName;
    }
}
